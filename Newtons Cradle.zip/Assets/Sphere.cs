﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sphere : MonoBehaviour {

    void Start ()
    {
       
        if (this.tag == "Sphere1")
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(-500.0f, 0.0f, 0.0f));
        }
    }
}
